package com.cts.controllers;

import java.util.List;

import static org.springframework.http.MediaType.*;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.Emp;
import com.cts.services.EmployeeService;

@RequestMapping("/emp/api")
@RestController
public class EmpController {
	private EmployeeService service;
	public EmpController(EmployeeService service) {
		super();
		this.service = service;
	}
	@GetMapping(value = "/employees",produces = {APPLICATION_JSON_VALUE,APPLICATION_XML_VALUE})
	public List<Emp> getEmployees(){
		return service.getEmployees();
	}
	@PostMapping(value ="/employees",produces = {APPLICATION_JSON_VALUE,APPLICATION_XML_VALUE},
			consumes ={APPLICATION_JSON_VALUE,APPLICATION_XML_VALUE} )
	public Emp insertEmployee(@RequestBody Emp e) {
		return service.insertEmployee(e);
	}
	@DeleteMapping(value = "/employees/{eno}",produces = {APPLICATION_JSON_VALUE,APPLICATION_XML_VALUE})
	public Emp deleteEmployee(@PathVariable("eno") int eno)
	{
		return service.deleteEmployee(eno);
	}
	@GetMapping(value = "/employees/{eno}",produces ={APPLICATION_JSON_VALUE,APPLICATION_XML_VALUE})
	public Emp getEmployee(@PathVariable("eno") int eno) {
		return service.getEmployee(eno);
	}
}
