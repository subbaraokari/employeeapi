package com.cts.services;

import java.util.List;

import com.cts.entity.Emp;

public interface EmployeeService {
	List<Emp> getEmployees();
	Emp getEmployee(int eno);
	Emp deleteEmployee(int eno);
	Emp insertEmployee(Emp e);
}
