package com.cts.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.entity.Emp;
import com.cts.repositories.EmpRepository;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	private EmpRepository repository;
	
	public EmployeeServiceImpl(EmpRepository repository) {
		super();
		this.repository = repository;
	}

	@Override
	public List<Emp> getEmployees() {
		return repository.findAll();
	}

	@Override
	public Emp getEmployee(int eno) {	
		return repository.findById(eno).orElse(null);
	}

	@Override
	public Emp deleteEmployee(int eno) {
		Emp e=getEmployee(eno);
		repository.delete(e);
		return e;
	}
	@Override
	public Emp insertEmployee(Emp e) {
		return repository.save(e);
	}
}
