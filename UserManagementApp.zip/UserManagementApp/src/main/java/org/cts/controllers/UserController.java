package org.cts.controllers;

import org.cts.entities.HttpResponse;
import org.cts.entities.User;
import org.cts.exceptions.UserExistsException;
import org.cts.services.UserService;
import org.cts.services.UserServiceImpl;

import static org.springframework.http.MediaType.*;
import java.util.List;

import static org.springframework.http.HttpStatus.*;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/usermanagement/api")
public class UserController {
	private static final String USER_DELETED_SUCCESSFULLY = "User Deleted Successfully";
	private UserService service;
	
	public UserController(UserServiceImpl service) {
		super();
		this.service = service;
	}

	@PostMapping(value = "/users",consumes = {APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			produces = {APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<User> register(@RequestBody User user) {
		User userEntity=service.register(user);
		return new ResponseEntity<User>(userEntity, CREATED);	
	}
	

	@GetMapping(value = "/users",produces = {APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<List<User>> getAllUsers(){
		List<User> users=service.getUsers();
		return new ResponseEntity<List<User>>(users, OK);
	}
	@DeleteMapping(value = "/users/{username}")
	public ResponseEntity<HttpResponse> deleteUser(@PathVariable("username") String username){
		service.deleteUser(username);
		return response(HttpStatus.OK, USER_DELETED_SUCCESSFULLY);
	}
	private ResponseEntity<HttpResponse> response(HttpStatus status,String message)
	{
		return new ResponseEntity<HttpResponse>(new HttpResponse(status.value(), status, 
				status.getReasonPhrase().toUpperCase().toString(),message), status);
	}
	
}
