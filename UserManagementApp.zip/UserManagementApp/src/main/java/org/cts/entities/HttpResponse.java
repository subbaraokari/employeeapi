package org.cts.entities;

import org.springframework.http.HttpStatus;

public class HttpResponse {
	private int statusCode;
	private HttpStatus httpStatus;
	private String reason;
	private String message;
	public HttpResponse() {
		// TODO Auto-generated constructor stub
	}
	public HttpResponse(int statusCode, HttpStatus httpStatus, String reason, String message) {
		super();
		this.statusCode = statusCode;
		this.httpStatus = httpStatus;
		this.reason = reason;
		this.message = message;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public HttpStatus getHttpStatus() {
		return httpStatus;
	}
	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
