package org.cts.services;

import java.util.List;

import org.cts.entities.User;

public interface UserService {
	User register(User user);
	List<User> getUsers();
	User findUserByUsername(String username);
	User findUserByEmail(String email);
	void deleteUser(String username);
	User updateUser(User user,String cuurrentUserName);

}
