package org.cts.services;

import java.util.List;

import org.cts.entities.User;
import org.cts.exceptions.EmailExistsException;
import org.cts.exceptions.UserExistsException;
import org.cts.repositories.UserRepository;
import org.springframework.stereotype.Service;
@Service
public class UserServiceImpl implements UserService {
	private UserRepository repository;
	
	public UserServiceImpl(UserRepository repository) {
		super();
		this.repository = repository;
	}

	@Override
	public User register(User user)throws UserExistsException,EmailExistsException {
		validateUserNameAndEmail(user);
		return repository.save(user);
	}

	private User validateUserNameAndEmail(User user)throws UserExistsException,EmailExistsException {
		if(user!=null) {
			User userByUserName=findUserByUsername(user.getUsername());
			User userByEmail=findUserByEmail(user.getEmail());
			if(userByUserName!=null)
				throw new UserExistsException("User with "+user.getUsername()+" allready existed");
			if(userByEmail!=null)
				throw new EmailExistsException("User with "+user.getEmail()+" allready existed");
		}
		return null;
	}

	@Override
	public List<User> getUsers() {
		return repository.findAll();
	}

	@Override
	public User findUserByUsername(String username) {
		return repository.findUserByUsername(username);
	}

	@Override
	public User findUserByEmail(String email) {
		return repository.findUserByEmail(email);
	}

	@Override
	public void deleteUser(String username) {
		User user=repository.findUserByUsername(username);
		if(user!=null)
		{
			repository.delete(user);
		}
	}

	@Override
	public User updateUser(User user, String cuurrentUserName) {
		User dbUser=repository.findUserByUsername(cuurrentUserName);
		dbUser.setFirstName(user.getFirstName());
		dbUser.setLastName(user.getLastName());
		dbUser.setUsername(user.getUsername());
		dbUser.setEmail(user.getEmail());
		dbUser.setJoiningDate(user.getJoiningDate());
		repository.save(dbUser);
		return dbUser;		
	}

}
