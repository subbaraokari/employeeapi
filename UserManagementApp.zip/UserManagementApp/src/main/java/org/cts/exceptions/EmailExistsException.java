package org.cts.exceptions;

public class EmailExistsException extends RuntimeException{
	public EmailExistsException(String desc) {
		super(desc);
	}
}
