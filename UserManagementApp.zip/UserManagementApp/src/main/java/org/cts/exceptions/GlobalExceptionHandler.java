package org.cts.exceptions;

import org.cts.entities.HttpResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(UserExistsException.class)
	public ResponseEntity<HttpResponse> userExistsException(UserExistsException ex){
		return new ResponseEntity<HttpResponse>(new HttpResponse(HttpStatus.BAD_REQUEST.value(), 
				HttpStatus.BAD_REQUEST,HttpStatus.BAD_REQUEST.getReasonPhrase().toUpperCase().toString() 
				, ex.getMessage()), HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(EmailExistsException.class)
	public ResponseEntity<HttpResponse> emailExistsException(EmailExistsException ex){
		return new ResponseEntity<HttpResponse>(new HttpResponse(HttpStatus.BAD_REQUEST.value(), 
				HttpStatus.BAD_REQUEST,HttpStatus.BAD_REQUEST.getReasonPhrase().toUpperCase().toString() 
				, ex.getMessage()), HttpStatus.BAD_REQUEST);
	}
}
