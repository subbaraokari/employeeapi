package org.cts.exceptions;

public class UserExistsException extends RuntimeException{
	public UserExistsException(String desc) {
		super(desc);
	}
}
