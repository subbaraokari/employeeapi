package org.cts.exceptions;

public class UserNorExistsException extends RuntimeException {
	public UserNorExistsException(String desc) {
		super(desc);
	}
}
