package org.ksr.services;

import org.cts.model.Student;

public interface StudentService {
	boolean registerStudent(Student student);
}
