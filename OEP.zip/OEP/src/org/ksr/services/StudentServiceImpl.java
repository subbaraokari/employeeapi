package org.ksr.services;

import org.cts.model.Student;
import org.ksr.dao.StudentDao;
import org.ksr.dao.StudentDaoImpl;

public class StudentServiceImpl implements StudentService {
	StudentDao dao=new StudentDaoImpl();
	@Override
	public boolean registerStudent(Student student) {
		boolean b=dao.register(student);
		System.out.println(b);
		return b;
	}

}
