package org.ksr.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	public static Connection getConnection(String driver,String url,String userName,String password) {
		Connection con=null;
		try {
			Class.forName(driver);
			con=DriverManager.getConnection(url,userName,password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

}
