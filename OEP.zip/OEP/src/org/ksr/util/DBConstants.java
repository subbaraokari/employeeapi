package org.ksr.util;

public class DBConstants {
	public static final String  DRIVER="com.mysql.cj.jdbc.Driver";
	public static final String  URL="jdbc:mysql://localhost:3306/mydb";
	public static final String UNAME="root";
	public static final String PASSWORD="root";

}
