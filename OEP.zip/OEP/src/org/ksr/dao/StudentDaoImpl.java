package org.ksr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.cts.model.Student;
import org.ksr.util.DBConstants;
import org.ksr.util.DBUtil;

public class StudentDaoImpl implements StudentDao {

	@Override
	public boolean register(Student student) {
		Connection con=null;
		PreparedStatement pst=null;
		boolean isRegistered=false;
		try {
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PASSWORD);
			if(con!=null)
			{
				pst=con.prepareStatement("insert into student(id,name,password,email,address,contactNo,regdDate,guardianName,mode) values(?,?,?,?,?,?,?,?,?)");
				pst.setInt(1, student.getId());
				pst.setString(2, student.getUsername());
				pst.setString(3, student.getPassword());
				pst.setString(4, student.getEmail());
				pst.setString(5, student.getAddress());
				pst.setString(6, student.getContactNo());
				pst.setString(7, student.getRegDate());
				pst.setString(8, student.getGuardianName());
				pst.setString(9, student.getMode());
				int a=pst.executeUpdate();
				System.out.println(a);
				if(a>0)
					isRegistered=true;
			}
		} catch (Exception e) {
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return isRegistered;
	}

}
