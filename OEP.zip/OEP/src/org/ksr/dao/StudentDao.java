package org.ksr.dao;

import org.cts.model.Student;

public interface StudentDao {
	boolean register(Student student);
}
