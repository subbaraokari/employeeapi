package org.ksr;

import org.cts.model.Student;
import org.ksr.services.StudentService;
import org.ksr.services.StudentServiceImpl;

public class Test {

	public static void main(String[] args) {
		StudentService service=new StudentServiceImpl();
		Student st1=new Student(1, "suresh", "suresh@123", "suresh@gmail.com", "Chennai", "76376326", "12/04/21", "suresh", "cash");
		boolean b=service.registerStudent(st1);
		if(b)
			System.out.println("registered successfully");
		else
			System.out.println("not registered");
	}

}
